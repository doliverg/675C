# keycap675E

## Over Under 2023-2024
### 10/6/23
#### Coded the drive and got the intake working.
### 10/8/23
#### Tested pneumatics of the two wings and the platform. The catapult isn't working.
#### Limit switch isn't being read for some reason.
### 10/13/23 - 10/15/23
#### The catapult wasn't being pressed on hard enough. New function used to read hte limit switch instead of the one on the PROS API.
#### Catapult is now functional, using pros::delay() and the motor running for a set amount of time.

