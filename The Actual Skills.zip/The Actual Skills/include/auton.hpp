#pragma once

#include "EZ-Template/drive/drive.hpp"

extern Drive chassis;
void default_constants();
void tune_PID();
//void comp_auton(); 
//void skills_auton();
void comp_autonV2();
//void skills_autonV2();
