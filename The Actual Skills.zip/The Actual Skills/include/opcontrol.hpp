#pragma once
#include "api.h"

// extern void intake_power(double percent);

void catapult();
int intakes();
void Wings();
void Hang();


