#pragma once
#include "api.h"

void intaker(double v);
void intaker_wait(double v, int time);
void outtaker(double v);
void movewings(bool way);
void wait(int time);
void move_hang(bool state);
void move_drive_wait(double target, int speed);
void turn_drive_wait(double target, int speed);
void outtaker_wait(double v, int time);
void run_cata(int time);
void drive_intake(double v, int driveVelocity, double intakeVelocity, int time);
void drive_wings(double v, int driveVelocity, bool way);
void drive_turn(double driveDistance, int driveVelocity, double turnDegrees, int turnVelocity);