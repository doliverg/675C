#include "api.h"

extern pros::Motor intake;
extern pros::Motor cata;

extern pros::ADIDigitalOut hangL;
extern pros::ADIDigitalOut hangR;
extern pros::ADIDigitalOut wingL;
extern pros::ADIDigitalOut wingR;
