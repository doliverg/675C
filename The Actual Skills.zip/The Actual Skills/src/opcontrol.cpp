#include "main.h"
#include "pros/adi.h"
#include "pros/misc.h"
#include "pros/motors.h"
//using namespace pros = no need to retype pros:: everytime

// local variable defined
const int vel = 600;
bool wings_state = false;
bool hang_state = false;
bool outtake = false;
bool CATANOTRUNNING = true;

void catapult() {
    while (true) {
        // If R1 is pressed, run catapult
        while(master.get_digital(pros::E_CONTROLLER_DIGITAL_L2))
        {
            //cata.move_voltage(12000);
            cata.move_velocity(63); 
            wait(10);
           // CATANOTRUNNING = false;
        }
        while(master.get_digital(pros::E_CONTROLLER_DIGITAL_L1)){
            cata.move_voltage(0);
            CATANOTRUNNING = true;
        }
         while(master.get_digital(pros::E_CONTROLLER_DIGITAL_X)){
            cata.move_velocity(50);
            wait(10);
            //CATANOTRUNNING = true;
        }
      
            cata.move_voltage(0);
            

        

    }
    pros::delay(ez::util::DELAY_TIME); 
}

int intakes() {
    while (true) {
        if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R1)) {
            intake.move_velocity(-vel); 
        }
        else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R2)) {
            intake.move_velocity(vel);
        }
        else {
            intake.move_velocity(0);
        }
        pros::delay(ez::util::DELAY_TIME);
        
    }
    pros::delay(ez::util::DELAY_TIME); 
    return 1;
}

void Wings() {
    // extends/retracts pistons when button is pressed 
    while (true) {
        if ((master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_A))) {
            if (wings_state == false) {  
                wings_state = !wings_state;
                movewings(wings_state);
            } else if (wings_state == true) {
                wings_state = !wings_state;
                movewings(wings_state);
            }
            

    pros::delay(ez::util::DELAY_TIME); 
        }   
    }
}
//code for hang
void Hang(){
    while(true){
        if((master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_Y))) {
            if(hang_state == false){
             hang_state = !hang_state;
                 move_hang(hang_state);
           // hangL.set_value(true);
            }
              else if (hang_state == true) {
                 hang_state = !hang_state;
                 move_hang(hang_state);
             }
             pros::delay(ez::util::DELAY_TIME);        
            }
       // else if ((master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_B))){
        //    hangL.set_value(false);
        }

    }
