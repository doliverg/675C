#include "main.h"
#include "pros/adi.h"
#include "pros/misc.h"
#include "pros/motors.h"

void intaker_wait(double v,int time) {
    intake.move_velocity(-v);
    pros::delay(time);
    intake.move_velocity(0);
}

void intaker(double v) {
    intake.move_velocity(-v);
}

void outtaker(double v) {
    intake.move_velocity(v);
}

void movewings(bool way) {
    wingL.set_value(way);
    wingR.set_value(way);
}

void wait(int time){
  pros::delay(time);
}

void move_hang(bool state){
    hangL.set_value(state);
    hangR.set_value(state);
}

void move_drive_wait(double target, int speed){
    chassis.set_drive_pid(target, speed);
    chassis.wait_drive();
}

void turn_drive_wait(double target, int speed) {
    chassis.set_turn_pid(target, speed);
    chassis.wait_drive();
}

void outtaker_wait(double v, int time){
    intake.move_velocity(v);
    pros::delay(time);
    intake.move_velocity(0);
}

void run_cata(int time){
    cata.move_voltage(-12000);
    pros::delay(time);
    cata.move_voltage(0);
}

void drive_intake(double target, int driveVelocity, double intakeVelocity, int time){
    intake.move_velocity(intakeVelocity);
    chassis.set_drive_pid(target, driveVelocity);
    pros::delay(time);
    intake.move_velocity(0);
}

void drive_wings(double target, int driveVelocity, bool way) {
    wingL.set_value(way);
    wingR.set_value(way);
    chassis.set_drive_pid(target, driveVelocity);
    chassis.wait_drive();
}
void drive_turn(double driveDistance, int driveVelocity, double turnDegrees, int turnVelocity) {
    chassis.set_drive_pid(driveDistance, driveVelocity);
    chassis.set_turn_pid(turnDegrees, turnVelocity);
}
