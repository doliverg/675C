#include "main.h"

void default_constants() //TUNE PID BASED OFF COMMENTS MADE BELOW
{
  chassis.set_slew_min_power(80, 80);
  chassis.set_slew_distance(7, 7);
  chassis.set_pid_constants(&chassis.headingPID, 11, 0, 20, 0);//increase D and decrease I (later on for this one) to decrease settling time = robot moves faster between calls
  chassis.set_pid_constants(&chassis.forward_drivePID, 0.45, 0, 5, 0);//increase D and decrease I (later on for this one) to decrease settling time = robot moves faster between calls
  chassis.set_pid_constants(&chassis.backward_drivePID, 0.45, 0, 5, 0); 
  chassis.set_pid_constants(&chassis.turnPID, 5, 0.003, 35, 15);//increase D and decrease I (later on for this one) to decrease settling time = robot moves faster between calls
  chassis.set_pid_constants(&chassis.swingPID, 7, 0, 45, 0);
}
//chassis.set_pid_constants(&chassis.headingPID, )
/*
HOW TO TUNE PID

Step 1 - kP
You'll start with kP. Set it to some number, and run your example autonomous. The robot will either undershoot the target (kP too low), or the robot is oscillate around the target (kP too high).

To tune a PD controller, you want the kP to oscillate a little bit, usually a bounce or two.

Step 2 - kD
After finding a kP that oscillates a little, we can tune kD. Increase kD until the oscillation goes away. This movement should look more "snappy" then just a P loop.

Step 3 - Repeat
Repeat Steps 1 and Steps 2 until kD cannot remove oscillation from the movement. Then go back to the last values that worked.

Step 4 - kI
Sometimes you need a little extra power to get your robot all the way there. Integral can be a dangerous variable because it grows exponentially. The fourth parameter is what the error needs to be for I to start. For turns, we found around 15 degrees is good.

Increase kI until any minor disturbances are accounted for. You might need to adjust kD while tuning kI.
*/

const int DRIVE_SPEED = 127;
const int Drive_speed = 110; // This is 110/127 (around 87% of max speed). When this is 87%, the robot is correcting by making one side
                            // faster and one side slower, giving better heading correction.
const int TURN_SPEED = 90;
const int SWING_SPEED = 90;

///
// Combining Turn + Drive basic set-up as of 10/8/23
///

//11/20/2023 UCB auton - Raymond

void tune_PID(){
  //go straight
  //go back
  //turn right
  //turn left
  //swing turn right
  //swing turn left
  //go straight for a while to check heading
}                                                                                                                                                                                                                                                                                                                                                                                                               


void comp_auton() {
  
  //preload into goal
  //detour 
  //push triballs 

// on our side, scores two triballs and continuously runs the catapult to matchload 
//chassis.set_swing_pid(RIGHT_SWING,100,-127,); left pin command

 
  intake.move_velocity(800); //Intake triball under elevation bar
  wait(300);
  move_drive_wait(10.5,80); //Drives to intake triball
  wait(700);
  intake.move_velocity(0);
  move_drive_wait(-12,127); //Moves backward
  turn_drive_wait(180,110); //Turns toward pvc pipe
  movewings(true); //Sweeps alliance triball
  wait(100);
  move_drive_wait(25,127); //Drives toward MLP
  turn_drive_wait(135,110); //Turns parallel to match load pvc
  move_drive_wait(30,127); //Drives toward wall
  turn_drive_wait(90,110); //Turns to facing the goal
  intake.move_velocity(-600); //Outtakes the triball
  wait(20);
  move_drive_wait(13,DRIVE_SPEED); //Drives both triballs into goal
  move_drive_wait(-13,DRIVE_SPEED); //Drives backward to reposition
  turn_drive_wait(20,110); //Turns to leftmost triball at the middle pvc pipe
  movewings(false);
  //wait(300);
  intake.move_velocity(800); 
  move_drive_wait(55,127); //Intakes leftmost triball and drives toward it
  wait(20);
  intake.move_velocity(0);
  turn_drive_wait(155,110); //Turns toward goal
  intake.move_velocity(-600); //Outtakes the triball
  move_drive_wait(10,127); //Pushes triball toward goal
  turn_drive_wait(30,110);
  intake.move_velocity(600);
  move_drive_wait(20,127);
  turn_drive_wait(180,110); //Turns toward goal
  /*move_drive_wait(-10,127); //Repositions with middle pvc pipe
  turn_drive_wait(90,110); //Turns toward top-center triball
  move_drive_wait(10,127); //Moves toward auton line
  turn_drive_wait(180,110); //Turns toward goal
  */
  movewings(true);
  move_drive_wait(40,127); //Pushes center triball and leftmost triball into goal
  movewings(false);
  /*turn_drive_wait(90,110);
  intake.move_velocity(600);
  move_drive_wait(25,127);
  turn_drive_wait(180,110);
  movewings(true);
  move_drive_wait(100,127);
  */
//

  //-----------------------add passive blocker 

/*
  intaker(600);
  move_drive_wait(-20,127);
  wait(500);
  intaker(0);
  turn_drive_wait(45,110);
  move_drive_wait(-18,110);
  move_drive_wait(15,127);
  move_drive_wait(-18,110);
  
  //detour 
  //loading 
  move_drive_wait(15,127);
  turn_drive_wait(120,110);
  move_drive_wait(3,90);
  
 //cata for 40 sec
  chassis.set_tank(20,20);
  cata.move_voltage(-12000);
  wait(40000);
  cata.move_voltage(0);
  chassis.set_tank(0,0);
 
 //go straight over the pvc pipe and push triballs in with wings deployed 
 move_drive_wait(45,100); 
 movewings(true); 
 move_drive_wait(15,100); 





  /*
  turn_drive_wait(165,110);
  move_drive_wait(-32,127);
  turn_drive_wait(135,110);
  move_drive_wait(-75,127); 
  //move_drive_wait(-90,127);
  //move away from matchload and go under the hang bar to the other matchload bar
  //goes to the other side matchload bar to score into the side of the goal
  
  turn_drive_wait(90,110);
  move_drive_wait(-25,127);
  turn_drive_wait(45,110);
  move_drive_wait(-18,127);
  move_drive_wait(10,110);
  move_drive_wait(-18,110); 
  move_drive_wait(6,110); 
  //chassis.set_tank(-127,-127);
  //wait(1000);
  //chassis.set_tank(127,127);
  //wait(500);
  //chassis.set_tank(-127,-127);
  //wait(600);
  //turn left from other side matchload and score into the side of the goal, back up then repush and back up again
  //this is where he scores and it doesnt score it all the way

  turn_drive_wait(-40,110);
  move_drive_wait(-45,127);
  turn_drive_wait(45,110);
  move_drive_wait(-24,127);
  turn_drive_wait(125,110);
  movewings(true);
  move_drive_wait(-32,127);
  move_drive_wait(15,127);
  move_drive_wait(-17,127);
  move_drive_wait(15,127);
  movewings(false);
  //turn the back of the bot towards the middle and drive towards it, turn the back towards the other side and drive to where the center of the goal would be, then turn towards the goal and open wings then push into the goal + back up + repush then close wings
*/

}
void comp_autonV2() {
  movewings(true); //Hits alliance triball towards goal
  wait(800);
  movewings(false);
  drive_intake(70,127,800,2500); //Intake and Drive to top-center triball
  turn_drive_wait(135,127); //Turns toward goal
  movewings(true);
  drive_intake(35,127,-600,1500); //Pushes top-center and center triball into goal
  drive_wings(-13,127,false); //Move backwards to reposition
  turn_drive_wait(-85,127); //Turns to left triball
  drive_intake(25,100,800, 1500); //Drives and intake left triball
  turn_drive_wait(-185,127); //Turns toward MLP
  move_drive_wait(55,127); //Drives to MLP
 //movewings(true);
  //move_hang(true);
  turn_drive_wait(-270,127); //Turn toward wall nearest to goal
  move_drive_wait(18,127); //Drives toward wall
  turn_drive_wait(-320,127);
  intake.move_velocity(-600);
  wait(500);
  //turn_drive_wait(-320,127); //Turns toward goal
  //intake.move_velocity(-600);
  //wait(500);
  move_drive_wait(30,127); //Pushes alliance triball and elevation triball in goal
  /*turn_drive_wait(-135,127); //Turns toward wall nearest to elevation pole
  move_drive_wait(15,127); //Drives toward wall
  turn_drive_wait(-45,127); //Turns toward elevation pole
  drive_intake(35.5, 127,600,2000); //Drive and Intake triball under elevation pole
  move_drive_wait(-12,127); //Move backwards
  turn_drive_wait(-225,127); //Turns toward MLP
  drive_wings(25,127,true); //Drives toward MLP
  
*/
}

void skills_auton() {
  intake.move_velocity(800); // Intakes the triball in front of it
  wait(100);
  turn_drive_wait(-45,110); // Turns parallel to the PVC pipe
  move_drive_wait(33,127); // Drives along the pipe to the wall
  turn_drive_wait(0,110); // Turns toward the goal
  intake.move_velocity(-600);
  wait(800);
  turn_drive_wait(180,127);
  move_drive_wait(-20, 127); // Pushes colored triball into goal
  move_drive_wait(13, 127); // Backs away from goal
  //turn_drive_wait(255,110); // Turns towards match load PVC pipe (MLP)
  chassis.set_swing_pid(LEFT_SWING,250,127); //right pin command 
  chassis.wait_drive();
  intake.move_velocity(0);
  cata.move_velocity(50); // Shoots triballs for 25 seconds
  wait(30000);
  cata.move_velocity(0);
  move_drive_wait(-5, 110);
  turn_drive_wait(120, 110);
  move_drive_wait(27,127); // Drive sideways into alley
  turn_drive_wait(90,110); // Corrects angle
  move_drive_wait(70, DRIVE_SPEED); // Drives onto other side
  turn_drive_wait(55,127);
  move_drive_wait(36,127);
  //movewings(true);
  //wait(200);
  turn_drive_wait(180,127);
  //move_drive_wait(10,127);
  move_drive_wait(-18,127);
  //movewings(false); // Retracts wings
  move_drive_wait(15,DRIVE_SPEED); // Backs away from goal
  turn_drive_wait(275,TURN_SPEED); // Turns towards middle PVC pipe
  move_drive_wait(50,127);
  //drive_wings(20,127,true);
  /*chassis.set_swing_pid(RIGHT_SWING,-0,127);
  chassis.wait_drive();
  chassis.set_swing_pid(RIGHT_SWING,-90,127);
  chassis.wait_drive();
  */
 // drive_wings(30,DRIVE_SPEED,false); // Drives to middle PVC pipe
  turn_drive_wait(30,127); // Turns towards goal
  movewings(true);
  wait(800);
  move_drive_wait(20, 127); //Pushes some triballs toward center
  movewings(false);
  move_drive_wait(-25,127);

  turn_drive_wait(0,TURN_SPEED); // Turns to the left
  move_drive_wait(35,127); // Drives to middle of field
  turn_drive_wait(90,TURN_SPEED); // Turns towards goal
  movewings(true); //Deploys wings
  wait(800);
  move_drive_wait(35,DRIVE_SPEED); // Drives into goal
  movewings(false); // retracts wings
  wait(800);
  move_drive_wait(-30,127); //Drive backward to middle pvc pipe
  turn_drive_wait(25,127); //Turn to match loading pipe
  drive_wings(70, 127, true); //Drive with wings to the MLP
  turn_drive_wait(135,127); //Turn parallel to MLP pipe 
  move_drive_wait(25,127); //Move to wall
  turn_drive_wait(180, 127); //Turn to goal
  move_drive_wait(20, 127); //Drive into goal
  movewings(false);
  wait(500);
  //drive_wings(-20,127, false); //Drive backward
  move_drive_wait(-20,127);
  turn_drive_wait(0,127); //Turn back to the goal
  move_drive_wait(-20,127); //Drive backward to the goal
}
  //chassis.set_swing_pid(RIGHT_SWING, -24, 127);
   

void skills_autonV2() {
  drive_turn(100,127, 45,60);
  /*intake.move_velocity(800); // Intakes the triball in front of it
  wait(100);
  turn_drive_wait(-45,110); // Turns parallel to the PVC pipe
  move_drive_wait(30,127); // Drives along the pipe to the wall
  turn_drive_wait(0,110); // Turns toward the goal
  intake.move_velocity(-600);
  wait(800);
    turn_drive_wait(180,127);
  move_drive_wait(-15, 127); // Pushes colored triball into goal
  move_drive_wait(25, 127); // Backs away from goal
  turn_drive_wait(265,110); // Turns towards match load PVC pipe (MLP) 
  intake.move_velocity(0);
  cata.move_velocity(70); // Shoots triballs for 25 seconds
  wait(5000);
  cata.move_velocity(0);
  move_drive_wait(-5, 127);
  turn_drive_wait(120, 127);
    drive_turn(35, 127, 30, 60);
  //move_drive_wait(35,127); // Drive sideways into alley
  //turn_drive_wait(90,127); // Corrects angle
  move_drive_wait(70, DRIVE_SPEED); // Drives onto other side
  turn_drive_wait(45,127);
  move_drive_wait(30,127);
  movewings(true);
  wait(200);
  turn_drive_wait(0,127);
  move_drive_wait(-10,127);
  move_drive_wait(25,127);
  movewings(false); // Retracts wings
  move_drive_wait(-6,DRIVE_SPEED); // Backs away from goal
  turn_drive_wait(-80,TURN_SPEED); // Turns towards middle PVC pipe
  move_drive_wait(50,DRIVE_SPEED); // Drives to middle PVC pipe
  turn_drive_wait(30,TURN_SPEED); // Turns towards goal
  movewings(true);
  wait(800);
  move_drive_wait(25, 127); //Pushes some triballs toward center
  movewings(false);
  move_drive_wait(-28,127);

  turn_drive_wait(0,TURN_SPEED); // Turns to the left
  move_drive_wait(40,127); // Drives to middle of field
  turn_drive_wait(90,TURN_SPEED); // Turns towards goal
  movewings(true); //Deploys wings
  wait(800);
  move_drive_wait(40,DRIVE_SPEED); // Drives into goal
  movewings(false); // retracts wings
  wait(800);
  drive_turn(-45,127, -45, 60); //drive backward to right corner with slight turn 
  movewings(true);
  wait(300);
  drive_turn(45, 127, 60, 80); //drive to goal with slight turn to right
  movewings(false);
  wait(300);
  drive_turn(-45, 127, 90, 127); //Drive backward to middle pvc pipe
  turn_drive_wait(0, 127); //turn to left corner 
  move_drive_wait(30,127); //Drive to left corner of middle pvc pipe
  turn_drive_wait(135, 127); //turn to goal
  movewings(true);
  wait(300);
  drive_turn(45,127, 90,60); //Drive to goal with slight left turn
  movewings(false); 
  move_drive_wait(-30,127); //Drive backward to middle pvc pipe
  turn_drive_wait(20,127); //Turn to match loading pipe
  drive_wings(40, 127, true); //Drive with wings to the MLP
  turn_drive_wait(135,127); //Turn parallel to MLP pipe 
  move_drive_wait(15,127); //Move to wall
  turn_drive_wait(180, 127); //Turn to goal
  move_drive_wait(20, 127); //Drive into goal
  drive_wings(-20,127, false); //Drive backward
  turn_drive_wait(0,127); //Turn back to the goal
  move_drive_wait(-20,127); //Drive backward to the goal
  */
}

  /*move_drive_wait(-35, DRIVE_SPEED); // Backs away from goal
  wait(400);
  turn_drive_wait(0, TURN_SPEED); // Turns right
  move_drive_wait(25, DRIVE_SPEED); // Drives forward to S3
  turn_drive_wait(60, TURN_SPEED); // Turns towards goal
  movewings(true);
  move_drive_wait(30, DRIVE_SPEED); // Drives into pvc pipe
  turn_drive_wait(45,TURN_SPEED); // Position parallel to pvc pipe
  move_drive_wait(15,DRIVE_SPEED); // drives forward toward wall
  turn_drive_wait(180,110); //Turns its back towards the goal
  move_drive_wait(30,127); //Drives into goal
  turn_drive_wait(0,110); //Turns back towards goal
  movewings(false);
  move_drive_wait(-40,127); //Moves backward into goal
  move_drive_wait(20,127); //Moves forward
  move_drive_wait(-40,127); //Moves backwards into goal
}
*/