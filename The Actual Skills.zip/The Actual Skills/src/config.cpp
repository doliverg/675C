#include "main.h"

pros::Motor intake(13, pros::E_MOTOR_GEARSET_06, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor cata(2, pros::E_MOTOR_GEARSET_36, pros::E_MOTOR_ENCODER_DEGREES);

pros::ADIDigitalOut hangL('B');
pros::ADIDigitalOut wingL('A');
pros::ADIDigitalOut wingR('A');
pros::ADIDigitalOut hangR('B');
//pros::ADIDigitalOut hangR('X');
